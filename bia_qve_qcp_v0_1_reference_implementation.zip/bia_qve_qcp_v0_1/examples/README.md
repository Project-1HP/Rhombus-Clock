Run `cryptosync-demo` after installation to generate a complete in-memory demonstration. The demo uses synthetic data only.
