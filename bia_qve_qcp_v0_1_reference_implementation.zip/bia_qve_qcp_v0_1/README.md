# Crypto Synchronous — BIA–QVE–QCP v0.1

A runnable reference implementation of:
- BIA: bootstrap and payload integrity verification
- QVE: evidence qualification against a Qualified Evidence Matrix
- QCP: quantitative calibration and tolerance checking
- CBBC-style quorum certificates: 7 validators, quorum 5, fault bound 2
- PPSA: append-only local audit records with SHA-256 digests

## Important scope

This is an educational/reference simulator, not a production consensus implementation.
The validator simulator demonstrates signature checking and quorum counting. It does **not**
implement full PBFT prepare/commit/view-change, safe membership reconfiguration, network
partitions, durable replicated consensus, HSM-backed key custody, or formal security proofs.
Do not use it to authorize real financial, legal, clinical, identity, or safety-critical actions.

A quorum means the configured validators signed the same statement. It does not prove that
external evidence is true. Hashes detect changes relative to a trusted digest; they do not
prove source authenticity or truth.

## Install

```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\\Scripts\\activate
pip install -e ".[test]"
pytest -q
```

## Run the demonstration

```bash
cryptosync-demo
# or
python -m cryptosync.simulator
```

## Layout

- `schemas/`: JSON Schema Draft 2020-12 contracts
- `src/cryptosync/`: service and simulator implementation
- `tests/`: automated acceptance tests

## Core flow

`BIA → QVE → QCP (when required) → signed quorum → PPSA audit`

A missing requirement is deferred; invalid authorization is rejected; a detected integrity
mismatch suspends the affected operation. Original input bytes are never silently rewritten.
