from datetime import datetime, timezone
import pytest

from cryptosync.core import digest_bytes, digest_object, Decision, validate_schema
from cryptosync.services import BIAService, QVEService, QCPService, PPSAService


def fixture_data():
    payload = b"immutable test payload"
    policy_hash = digest_object({"policy": "test"}, "CBBC_POLICY_V1")
    config_hash = digest_object({"config": "test"}, "BIA_CONFIG_V1")
    now = datetime.now(timezone.utc).isoformat()
    manifest = {
        "protocol": "BIA", "version": "0.1", "bootstrap_id": "boot-1",
        "network_id": "test-net", "system_id": "system-1",
        "configuration_hash": config_hash, "policy_hash": policy_hash,
        "payload_hash": digest_bytes(payload, "BIA_PAYLOAD_V1"),
        "provenance_id": "prov-1", "key_reference": "key-1",
        "created_at": now, "status": "PENDING"
    }
    evidence = {
        "evidence_id": "ev-1", "task_id": "task-1", "evidence_type": "DOCUMENT",
        "source_reference": "fixture", "payload_hash": digest_bytes(payload, "BIA_PAYLOAD_V1"),
        "provenance_id": "prov-1", "collected_at": now, "policy_hash": policy_hash,
        "calibration_reference": None, "qualitative_review_reference": None, "status": "PENDING"
    }
    return payload, policy_hash, config_hash, manifest, evidence


def test_bia_valid(schema_dir):
    payload, policy, config, manifest, _ = fixture_data()
    assert BIAService(schema_dir).verify(manifest, payload, "test-net", config, {policy}) == Decision.VERIFIED


def test_bia_payload_tamper_suspends(schema_dir):
    payload, policy, config, manifest, _ = fixture_data()
    assert BIAService(schema_dir).verify(manifest, payload + b"tampered", "test-net", config, {policy}) == Decision.SUSPENDED


def test_bia_wrong_network_rejected(schema_dir):
    payload, policy, config, manifest, _ = fixture_data()
    assert BIAService(schema_dir).verify(manifest, payload, "other-net", config, {policy}) == Decision.REJECTED


def test_qve_all_pass(schema_dir):
    payload, policy, _, _, evidence = fixture_data()
    qem = {name: "PASS" for name in QVEService.DIMENSIONS}
    result = QVEService(schema_dir).evaluate(evidence, qem, payload, policy)
    assert result["decision"] == "VERIFIED"


def test_qve_unknown_defers(schema_dir):
    payload, policy, _, _, evidence = fixture_data()
    qem = {name: "PASS" for name in QVEService.DIMENSIONS}
    qem["source"] = "UNKNOWN"
    result = QVEService(schema_dir).evaluate(evidence, qem, payload, policy)
    assert result["decision"] == "DEFERRED"


def test_qve_integrity_failure_suspends(schema_dir):
    payload, policy, _, _, evidence = fixture_data()
    qem = {name: "PASS" for name in QVEService.DIMENSIONS}
    qem["integrity"] = "FAIL"
    result = QVEService(schema_dir).evaluate(evidence, qem, payload, policy)
    assert result["decision"] == "SUSPENDED"


def calibration_record():
    return {
        "calibration_id": "cal-1", "task_id": "task-1", "measurement_type": "TEMP",
        "reference_value": 100.0, "observed_value": 99.98, "unit": "UNIT",
        "tolerance": 0.05, "absolute_deviation": 0.02, "reference_source": "trusted-ref",
        "uncertainty": 0.01, "method_version": "1.0",
        "calibrated_at": datetime.now(timezone.utc).isoformat(), "result": "PASS"
    }


def test_qcp_pass(schema_dir):
    result = QCPService(schema_dir).calibrate(calibration_record())
    assert result["result"] == "PASS"


def test_qcp_fail_outside_tolerance(schema_dir):
    record = calibration_record()
    record["observed_value"] = 99.0
    record["absolute_deviation"] = 1.0
    assert QCPService(schema_dir).calibrate(record)["result"] == "FAIL"


def test_qcp_rejects_wrong_deviation(schema_dir):
    record = calibration_record()
    record["absolute_deviation"] = 0.5
    with pytest.raises(ValueError):
        QCPService(schema_dir).calibrate(record)


def test_ppsa_detects_tampering():
    store = PPSAService()
    store.append({"event": "one"})
    store.append({"event": "two"})
    assert store.verify_chain()
    store.records[0]["record"]["event"] = "altered"
    assert not store.verify_chain()
