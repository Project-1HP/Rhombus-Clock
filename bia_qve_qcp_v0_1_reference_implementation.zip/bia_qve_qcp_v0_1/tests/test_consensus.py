from cryptosync.consensus import SevenValidatorSimulator
from cryptosync.core import digest_object


def setup_sim():
    sim = SevenValidatorSimulator.create()
    statement = sim.statement(
        "operation-1",
        digest_object({"result": "verified"}, "TEST_PROPOSAL"),
        digest_object({"policy": 1}, "TEST_POLICY")
    )
    return sim, statement


def test_seven_validator_quorum_is_five():
    sim, statement = setup_sim()
    cert = sim.certificate(statement, [
        "validator-01", "validator-02", "validator-03", "validator-04", "validator-05"
    ])
    assert sim.n == 7 and sim.f == 2 and sim.quorum == 5
    assert cert["valid"]


def test_four_signatures_insufficient():
    sim, statement = setup_sim()
    cert = sim.certificate(statement, [
        "validator-01", "validator-02", "validator-03", "validator-04"
    ])
    assert not cert["valid"]


def test_tampered_statement_invalidates_signatures():
    sim, statement = setup_sim()
    signatures = sim.collect(statement, [
        "validator-01", "validator-02", "validator-03", "validator-04", "validator-05"
    ])
    altered = dict(statement)
    altered["policy_hash"] = "different-policy"
    assert not sim.verify_certificate(altered, signatures)


def test_duplicate_signer_rejected():
    sim, statement = setup_sim()
    signatures = sim.collect(statement, [
        "validator-01", "validator-02", "validator-03", "validator-04", "validator-05"
    ])
    signatures.append(signatures[0])
    assert not sim.verify_certificate(statement, signatures)
