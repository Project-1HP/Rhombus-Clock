from pathlib import Path
import pytest

@pytest.fixture
def schema_dir():
    return Path(__file__).resolve().parents[1] / "schemas"
