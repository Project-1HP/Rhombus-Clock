from __future__ import annotations

import base64
from dataclasses import dataclass
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

from .core import canonical_json, digest_object


@dataclass
class SigningIdentity:
    validator_id: str
    private_key: Ed25519PrivateKey

    @classmethod
    def generate(cls, validator_id: str) -> "SigningIdentity":
        return cls(validator_id, Ed25519PrivateKey.generate())

    def public_key_bytes(self) -> bytes:
        return self.private_key.public_key().public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw
        )

    def sign_statement(self, statement: dict) -> str:
        return base64.b64encode(self.private_key.sign(canonical_json(statement))).decode("ascii")


def verify_signature(public_key_bytes: bytes, statement: dict, signature_b64: str) -> bool:
    try:
        signature = base64.b64decode(signature_b64, validate=True)
        Ed25519PublicKey.from_public_bytes(public_key_bytes).verify(
            signature, canonical_json(statement)
        )
        return True
    except (ValueError, InvalidSignature):
        return False


def statement_digest(statement: dict) -> str:
    return digest_object(statement, "CBBC_QUORUM_STATEMENT_V1")
