from __future__ import annotations

from dataclasses import dataclass
from .crypto import SigningIdentity, verify_signature, statement_digest


@dataclass
class Validator:
    identity: SigningIdentity
    active: bool = True
    byzantine: bool = False

    @property
    def validator_id(self) -> str:
        return self.identity.validator_id

    @property
    def public_key(self) -> bytes:
        return self.identity.public_key_bytes()


class SevenValidatorSimulator:
    """Quorum-signature demonstration, not a complete PBFT implementation."""
    def __init__(self, validators: list[Validator], max_faults: int = 2):
        self.validators = {v.validator_id: v for v in validators}
        self.n = len(validators)
        self.f = max_faults
        if self.n != 3 * self.f + 1:
            raise ValueError("validator count must equal 3f+1 for this profile")
        self.quorum = 2 * self.f + 1

    @classmethod
    def create(cls, count: int = 7, max_faults: int = 2):
        validators = [
            Validator(SigningIdentity.generate(f"validator-{i+1:02d}"))
            for i in range(count)
        ]
        return cls(validators, max_faults)

    def statement(self, operation_id: str, proposal_digest: str,
                  policy_hash: str, epoch: int = 1, sequence: int = 1) -> dict:
        return {
            "protocol": "CBBC-BIA-QVE-QCP",
            "network_id": "demo-network",
            "operation_id": operation_id,
            "proposal_digest": proposal_digest,
            "policy_hash": policy_hash,
            "epoch": epoch,
            "sequence": sequence
        }

    def collect(self, statement: dict, signer_ids: list[str] | None = None) -> list[dict]:
        selected = signer_ids or list(self.validators)
        signatures = []
        for validator_id in selected:
            validator = self.validators[validator_id]
            if validator.active:
                signatures.append({
                    "validator_id": validator_id,
                    "signature": validator.identity.sign_statement(statement)
                })
        return signatures

    def verify_certificate(self, statement: dict, signatures: list[dict]) -> bool:
        seen = set()
        valid = 0
        for item in signatures:
            validator_id = item["validator_id"]
            if validator_id in seen or validator_id not in self.validators:
                return False
            seen.add(validator_id)
            validator = self.validators[validator_id]
            if not validator.active:
                return False
            if not verify_signature(validator.public_key, statement, item["signature"]):
                return False
            valid += 1
        return valid >= self.quorum

    def certificate(self, statement: dict, signer_ids: list[str] | None = None) -> dict:
        signatures = self.collect(statement, signer_ids)
        return {
            "statement": statement,
            "statement_digest": statement_digest(statement),
            "required_quorum": self.quorum,
            "signatures": signatures,
            "valid": self.verify_certificate(statement, signatures)
        }
