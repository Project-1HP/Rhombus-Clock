from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from .core import digest_bytes, digest_object
from .services import BIAService, QVEService, QCPService, PPSAService
from .consensus import SevenValidatorSimulator

ROOT = Path(__file__).resolve().parents[2]
SCHEMAS = ROOT / "schemas"


def main():
    payload = b"example evidence payload; not a real identity or financial record"
    policy = {"policy": "demo-policy", "version": 1}
    policy_hash = digest_object(policy, "CBBC_POLICY_V1")
    config_hash = digest_object({"runtime": "demo", "version": 1}, "BIA_CONFIG_V1")

    manifest = {
        "protocol": "BIA", "version": "0.1", "bootstrap_id": "bootstrap-demo-001",
        "network_id": "demo-network", "system_id": "demo-system",
        "configuration_hash": config_hash, "policy_hash": policy_hash,
        "payload_hash": digest_bytes(payload, "BIA_PAYLOAD_V1"),
        "provenance_id": "provenance-demo-001", "key_reference": "demo-key-001",
        "created_at": datetime.now(timezone.utc).isoformat(), "status": "PENDING"
    }
    bia = BIAService(SCHEMAS)
    bootstrap_status = bia.verify(manifest, payload, "demo-network", config_hash, {policy_hash})

    evidence = {
        "evidence_id": "evidence-demo-001", "task_id": "task-demo-001",
        "evidence_type": "DOCUMENT", "source_reference": "local-demo-fixture",
        "payload_hash": digest_bytes(payload, "BIA_PAYLOAD_V1"),
        "provenance_id": "provenance-demo-001",
        "collected_at": datetime.now(timezone.utc).isoformat(),
        "policy_hash": policy_hash, "calibration_reference": None,
        "qualitative_review_reference": "review-demo-001", "status": "PENDING"
    }
    qem = {name: "PASS" for name in QVEService.DIMENSIONS}
    qve_result = QVEService(SCHEMAS).evaluate(
        evidence, qem, payload, policy_hash,
        calibration_required=True, calibration_passed=True,
        qualitative_required=True, qualitative_review_present=True
    )

    calibration = {
        "calibration_id": "cal-demo-001", "task_id": "task-demo-001",
        "measurement_type": "TEMPERATURE", "reference_value": 21.4,
        "observed_value": 21.5, "unit": "CELSIUS", "tolerance": 0.2,
        "absolute_deviation": 0.1, "reference_source": "demo-reference",
        "uncertainty": 0.05, "method_version": "1.0",
        "calibrated_at": datetime.now(timezone.utc).isoformat(), "result": "PASS"
    }
    qcp_result = QCPService(SCHEMAS).calibrate(calibration)

    validators = SevenValidatorSimulator.create()
    statement = validators.statement(
        "task-demo-001", digest_object(qve_result, "QVE_RESULT_V1"), policy_hash
    )
    certificate = validators.certificate(statement, [
        "validator-01", "validator-02", "validator-03", "validator-04", "validator-05"
    ])

    ppsa = PPSAService()
    ppsa.append({"type": "BOOTSTRAP", "status": bootstrap_status.value})
    ppsa.append({"type": "QVE", "result": qve_result})
    ppsa.append({"type": "QCP", "result": qcp_result})
    ppsa.append({"type": "QUORUM", "valid": certificate["valid"]})

    print(json.dumps({
        "bootstrap": bootstrap_status.value,
        "qve": qve_result["decision"],
        "qcp": qcp_result["result"],
        "validators": validators.n,
        "fault_tolerance": validators.f,
        "quorum_required": validators.quorum,
        "quorum_certificate_valid": certificate["valid"],
        "ppsa_records": len(ppsa.records),
        "ppsa_chain_valid": ppsa.verify_chain()
    }, indent=2))


if __name__ == "__main__":
    main()
