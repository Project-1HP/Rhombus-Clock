from __future__ import annotations

import hashlib
import json
import math
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator, FormatChecker


class Decision(str, Enum):
    VERIFIED = "VERIFIED"
    DEFERRED = "DEFERRED"
    REJECTED = "REJECTED"
    SUSPENDED = "SUSPENDED"


def canonical_json(value: Any) -> bytes:
    """Deterministic JSON encoding for this reference profile."""
    return json.dumps(
        value, sort_keys=True, separators=(",", ":"), ensure_ascii=False,
        allow_nan=False
    ).encode("utf-8")


def digest_bytes(data: bytes, domain: str = "GENERIC_V1") -> str:
    return "sha256:" + hashlib.sha256(domain.encode("utf-8") + b"\\0" + data).hexdigest()


def digest_object(value: Any, domain: str) -> str:
    return digest_bytes(canonical_json(value), domain)


def validate_schema(instance: dict, schema_path: str | Path) -> None:
    schema = json.loads(Path(schema_path).read_text(encoding="utf-8"))
    Draft202012Validator.check_schema(schema)
    validator = Draft202012Validator(schema, format_checker=FormatChecker())
    errors = sorted(validator.iter_errors(instance), key=lambda e: list(e.path))
    if errors:
        details = "; ".join(f"{list(e.path)}: {e.message}" for e in errors)
        raise ValueError(f"schema validation failed: {details}")


def parse_utc(value: str) -> datetime:
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        raise ValueError("timestamp must include timezone")
    return parsed


def finite_number(value: Any) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)
