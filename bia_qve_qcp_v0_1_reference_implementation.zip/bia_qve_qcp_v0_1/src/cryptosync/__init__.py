"""Crypto Synchronous BIA-QVE-QCP reference package."""
__version__ = "0.1.0"
