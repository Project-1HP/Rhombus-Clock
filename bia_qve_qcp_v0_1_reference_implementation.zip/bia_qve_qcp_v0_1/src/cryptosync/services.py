from __future__ import annotations

import math
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .core import Decision, digest_bytes, digest_object, finite_number, validate_schema


class BIAService:
    def __init__(self, schema_dir: str | Path):
        self.schema_dir = Path(schema_dir)

    def verify(self, manifest: dict, payload: bytes, expected_network: str,
               trusted_configuration_hash: str, authorized_policy_hashes: set[str]) -> Decision:
        validate_schema(manifest, self.schema_dir / "bootstrap_manifest.schema.json")
        if manifest["network_id"] != expected_network:
            return Decision.REJECTED
        if manifest["configuration_hash"] != trusted_configuration_hash:
            return Decision.SUSPENDED
        if manifest["policy_hash"] not in authorized_policy_hashes:
            return Decision.REJECTED
        actual = digest_bytes(payload, "BIA_PAYLOAD_V1")
        if actual != manifest["payload_hash"]:
            return Decision.SUSPENDED
        return Decision.VERIFIED


class QVEService:
    DIMENSIONS = ("source", "provenance", "accuracy", "consistency",
                  "integrity", "completeness", "authorization", "reproducibility")

    def __init__(self, schema_dir: str | Path):
        self.schema_dir = Path(schema_dir)

    def evaluate(self, evidence: dict, qem: dict, payload: bytes,
                 policy_hash: str, calibration_required: bool = False,
                 calibration_passed: bool | None = None,
                 qualitative_required: bool = False,
                 qualitative_review_present: bool = False) -> dict:
        validate_schema(evidence, self.schema_dir / "evidence_record.schema.json")
        if evidence["policy_hash"] != policy_hash:
            return {"decision": Decision.REJECTED.value, "reason": "POLICY_MISMATCH"}
        if digest_bytes(payload, "BIA_PAYLOAD_V1") != evidence["payload_hash"]:
            return {"decision": Decision.SUSPENDED.value, "reason": "PAYLOAD_MISMATCH"}
        missing = [d for d in self.DIMENSIONS if d not in qem or qem[d] not in ("PASS", "FAIL", "UNKNOWN", "NOT_APPLICABLE")]
        if missing:
            return {"decision": Decision.DEFERRED.value, "reason": "QEM_INCOMPLETE", "missing": missing}
        failed = [d for d in self.DIMENSIONS if qem[d] == "FAIL"]
        unknown = [d for d in self.DIMENSIONS if qem[d] == "UNKNOWN"]
        if "integrity" in failed:
            return {"decision": Decision.SUSPENDED.value, "reason": "INTEGRITY_FAILURE"}
        if failed:
            return {"decision": Decision.REJECTED.value, "reason": "REQUIREMENT_FAILED", "failed": failed}
        if unknown:
            return {"decision": Decision.DEFERRED.value, "reason": "REQUIREMENTS_UNKNOWN", "unknown": unknown}
        if calibration_required and calibration_passed is not True:
            return {"decision": Decision.DEFERRED.value, "reason": "CALIBRATION_NOT_PASSED"}
        if qualitative_required and not qualitative_review_present:
            return {"decision": Decision.DEFERRED.value, "reason": "QUALITATIVE_REVIEW_MISSING"}
        return {
            "decision": Decision.VERIFIED.value,
            "reason": "ALL_REQUIRED_CHECKS_PASSED",
            "evidence_digest": digest_object(evidence, "QVE_EVIDENCE_V1"),
            "qem": dict(qem)
        }


class QCPService:
    def __init__(self, schema_dir: str | Path):
        self.schema_dir = Path(schema_dir)

    def calibrate(self, record: dict, reference_trusted: bool = True,
                  compatible_units: bool = True) -> dict:
        validate_schema(record, self.schema_dir / "calibration_result.schema.json")
        values = (record["reference_value"], record["observed_value"],
                  record["tolerance"], record["absolute_deviation"])
        if not all(finite_number(v) for v in values):
            raise ValueError("numeric fields must be finite numbers")
        if not reference_trusted:
            result = "INDETERMINATE"
            reason = "UNTRUSTED_REFERENCE"
        elif not compatible_units:
            raise ValueError("incompatible units")
        else:
            deviation = abs(record["observed_value"] - record["reference_value"])
            if not math.isclose(deviation, record["absolute_deviation"], rel_tol=0, abs_tol=1e-12):
                raise ValueError("absolute_deviation does not match calculated deviation")
            result = "PASS" if deviation <= record["tolerance"] else "FAIL"
            reason = "WITHIN_TOLERANCE" if result == "PASS" else "OUTSIDE_TOLERANCE"
        output = dict(record)
        output["result"] = result
        output["reason"] = reason
        return output


class PPSAService:
    """Small append-only local audit journal; not a replicated/perpetual store."""
    def __init__(self):
        self.records: list[dict] = []

    def append(self, record: dict) -> dict:
        from .core import canonical_json
        previous = self.records[-1]["record_hash"] if self.records else "GENESIS"
        body = {"index": len(self.records), "previous_hash": previous, "record": record}
        record_hash = digest_object(body, "PPSA_AUDIT_RECORD_V1")
        stored = {**body, "record_hash": record_hash}
        self.records.append(stored)
        return stored

    def verify_chain(self) -> bool:
        previous = "GENESIS"
        for index, item in enumerate(self.records):
            body = {"index": index, "previous_hash": previous, "record": item["record"]}
            if item["index"] != index or item["previous_hash"] != previous:
                return False
            if item["record_hash"] != digest_object(body, "PPSA_AUDIT_RECORD_V1"):
                return False
            previous = item["record_hash"]
        return True
